Douyin Single Image-Text Publisher v2.2.7 Clean Update

Based on user's v2.2 random-image base version.

Kept features:
- Random image checkbox: if enabled, each post randomly selects one image from image folder.
- If disabled, keeps original filename-sorted first-image logic.
- Character-by-character text input in fill_copy(): uses page.keyboard.type(), does not use clipboard for body/topics.

Fixes:
- Limits copy file selector to .xlsx/.xls/.xlsm/.csv/.txt.
- Blocks .py or other script files from being used as copy file, avoiding WPS opening Python code as a spreadsheet.
- Clean package structure, removes duplicate Chinese-name py/pyw files, .spec, lnk, helper scripts not needed for online update.
- Keeps default system py behavior. Does NOT force py -3.12.

Start:
- Recommended: Start_Douyin_Publisher_v2.2.vbs
- Generic: start_app.vbs
- Debug: debug_start.bat
