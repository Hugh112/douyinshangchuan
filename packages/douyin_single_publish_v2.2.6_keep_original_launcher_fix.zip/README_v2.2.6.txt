Douyin Single Image-Text Publisher v2.2.6

Fixes:
1. Updates APP_NAME/window title to v2.2.6.
2. Replaces old launcher names as well as new launcher names, so existing user shortcuts can continue opening the updated app.
3. Keeps ASCII-only package filenames to avoid mojibake in Windows Explorer.
4. Keeps WPS .py misselect fix.
5. Does not force Python 3.12. It still uses system default py.

Start:
- Existing old launchers should continue to work.
- Recommended: Start_Douyin_Publisher.vbs or Start_Douyin_Publisher_v2.1.vbs
- Debug: debug_start.bat
