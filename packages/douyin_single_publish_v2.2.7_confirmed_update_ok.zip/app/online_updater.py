# -*- coding: utf-8 -*-
"""Simple online updater for Douyin Publisher."""
import argparse
import hashlib
import json
import os
import shutil
import subprocess
import sys
import tempfile
import time
import urllib.request
import zipfile
from pathlib import Path


def download_with_retry(url, dst, retry=3, timeout=60):
    headers = {"User-Agent": "DouyinPublisherUpdater/2.2.7", "Cache-Control": "no-cache", "Pragma": "no-cache", "Connection": "close"}
    last_err = None
    sep = "&" if "?" in url else "?"
    url2 = f"{url}{sep}_t={int(time.time())}"
    for i in range(max(1, retry)):
        try:
            req = urllib.request.Request(url2, headers=headers)
            with urllib.request.urlopen(req, timeout=timeout) as r, open(dst, "wb") as f:
                shutil.copyfileobj(r, f)
            return
        except Exception as e:
            last_err = e
            time.sleep(2 + i * 2)
    raise last_err


def sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def wait_process_exit(pid, seconds=8):
    try:
        pid = int(pid or 0)
    except Exception:
        pid = 0
    if not pid:
        return
    if os.name != "nt":
        time.sleep(2)
        return
    try:
        import ctypes
        SYNCHRONIZE = 0x00100000
        handle = ctypes.windll.kernel32.OpenProcess(SYNCHRONIZE, False, pid)
        if handle:
            ctypes.windll.kernel32.WaitForSingleObject(handle, int(seconds * 1000))
            ctypes.windll.kernel32.CloseHandle(handle)
        else:
            time.sleep(2)
    except Exception:
        time.sleep(2)


def copy_tree(src, dst, preserve_paths):
    src = Path(src)
    dst = Path(dst)
    preserve_paths = set(str(p).replace(chr(92), "/") for p in preserve_paths or [])
    backups = {}
    for rel in preserve_paths:
        p = dst / rel
        if p.exists():
            backups[rel] = p.read_bytes()
    for root, dirs, files in os.walk(src):
        rootp = Path(root)
        rel_root = rootp.relative_to(src)
        for name in files:
            src_file = rootp / name
            rel = (rel_root / name).as_posix()
            if rel in preserve_paths:
                continue
            dst_file = dst / rel
            dst_file.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(src_file, dst_file)
    for rel, data in backups.items():
        p = dst / rel
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_bytes(data)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--install-dir", required=True)
    ap.add_argument("--current-pid", default="0")
    ap.add_argument("--download-url", required=True)
    ap.add_argument("--sha256", default="")
    ap.add_argument("--launch", default="")
    ap.add_argument("--preserve", default="[]")
    args = ap.parse_args()
    install_dir = Path(args.install_dir).resolve()
    preserve = json.loads(args.preserve or "[]")
    tmp = Path(tempfile.mkdtemp(prefix="douyin_update_"))
    zip_path = tmp / "update.zip"
    extract_dir = tmp / "extract"
    try:
        download_with_retry(args.download_url, zip_path)
        if args.sha256:
            got = sha256_file(zip_path).lower()
            want = args.sha256.lower().strip()
            if got != want:
                raise RuntimeError(f"SHA256 mismatch. want={want}, got={got}")
        extract_dir.mkdir(parents=True, exist_ok=True)
        with zipfile.ZipFile(zip_path, "r") as z:
            z.extractall(extract_dir)
        children = [p for p in extract_dir.iterdir() if p.name != "__MACOSX"]
        if len(children) == 1 and children[0].is_dir() and not (extract_dir / "app").exists():
            src_root = children[0]
        else:
            src_root = extract_dir
        wait_process_exit(args.current_pid)
        copy_tree(src_root, install_dir, preserve)
        launch = Path(args.launch) if args.launch else install_dir / "app" / "app_main.pyw"
        if launch.name.lower() in {"app_main.py", "app_main.pyw"}:
            launch = install_dir / "app" / launch.name
        if launch.exists():
            subprocess.Popen([sys.executable, str(launch)], cwd=str(launch.parent))
    except Exception as e:
        try:
            import tkinter as tk
            from tkinter import messagebox
            root = tk.Tk(); root.withdraw()
            messagebox.showerror("更新失败", repr(e))
            root.destroy()
        except Exception:
            pass
        raise
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


if __name__ == "__main__":
    main()
