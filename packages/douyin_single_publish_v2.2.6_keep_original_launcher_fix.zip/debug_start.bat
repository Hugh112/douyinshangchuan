@echo off
cd /d "%~dp0app"
call debug_start.bat
