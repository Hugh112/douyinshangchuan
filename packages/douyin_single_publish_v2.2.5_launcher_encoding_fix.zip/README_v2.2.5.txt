Douyin Single Image-Text Publisher v2.2.5

Fixes:
1. Adds root-level launchers for online update package.
2. Uses ASCII-only filenames in the zip package to avoid mojibake in Windows Explorer/WPS.
3. Keeps app/app_main.py and app/app_main.pyw from the WPS .py misselect fix version.
4. Keeps default Python launcher behavior. It does NOT force py -3.12.

Start:
- Double click Start_Douyin_Publisher_v2.2.5.vbs
- If it does not open, run debug_start_v2.2.5.bat

Online update note:
This package is a flat update package. It contains root launchers and app/ directory directly.
