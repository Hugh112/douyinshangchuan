# 抖音单图文发布 v2.2.9

## 更新内容

- 修复正常启动时出现或停留黑色命令行窗口的问题。
- 新增无黑框 VBS 启动器。
- 隐藏 PowerShell、taskkill、浏览器、发布工作进程和在线更新器产生的控制台窗口。
- 更新完成后自动以无窗口方式重新启动。
- 保留 `debug_start.bat` 调试入口；调试模式显示控制台属于正常行为。

## 使用方式

推荐双击 `启动抖音发布器_无黑框.vbs` 或 `Start_Douyin_Publisher.vbs`。

## 自动更新

将 `douyin_single_publish_v2.2.9_no_black_window_update.zip` 上传到 GitHub Release `v2.2.9`，并将本目录中的 `version.json` 覆盖到仓库 `main` 分支根目录。

SHA256：`ce40eb3bbeb29da88f4061002ccc10fc46151f56f0bdace0f6137997b9ed2836`
