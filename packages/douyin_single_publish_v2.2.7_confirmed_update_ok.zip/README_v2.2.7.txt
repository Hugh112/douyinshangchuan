Douyin Single Image-Text Publisher v2.2.7

Based on your v2.2.3 code.
Kept:
- Check update button and online updater
- Random image option
- Character-by-character input
Fixed:
- version manifest cache fallback
- WPS/.py misselect guard
- clean package structure

Start with Start_Douyin_Publisher_v2.2.vbs or start_app.vbs.
