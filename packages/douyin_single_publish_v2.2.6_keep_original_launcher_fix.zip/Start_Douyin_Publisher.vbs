Option Explicit

Dim fso, shell, here, appDir, batPath

Set fso = CreateObject("Scripting.FileSystemObject")
Set shell = CreateObject("WScript.Shell")

here = fso.GetParentFolderName(WScript.ScriptFullName)

If fso.FileExists(fso.BuildPath(here, "start_app.bat")) Then
    appDir = here
ElseIf fso.FolderExists(fso.BuildPath(here, "app")) Then
    appDir = fso.BuildPath(here, "app")
Else
    MsgBox "Cannot find app folder or start_app.bat:" & vbCrLf & here, 48, "Start failed"
    WScript.Quit 1
End If

batPath = fso.BuildPath(appDir, "start_app.bat")

If Not fso.FileExists(batPath) Then
    MsgBox "Cannot find start file:" & vbCrLf & batPath, 48, "Start failed"
    WScript.Quit 1
End If

shell.CurrentDirectory = appDir
shell.Run "cmd.exe /c " & Chr(34) & batPath & Chr(34), 0, False
